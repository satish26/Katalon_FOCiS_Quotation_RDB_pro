package fn.RDB

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import com.kms.katalon.core.webui.driver.DriverFactory


public class naviageTo {


	@Keyword
	public void AgilityTariff(){


		'Click on \'Rate Cloud & NPC Menu\'.'
		WebUI.click(findTestObject('RDB/Menu/Rate_Cloud_and_NPC_Menu'))

		WebUI.delay(2)

		WebUI.mouseOver(findTestObject('RDB/Menu/Agility_Tariff_Menu'))

		WebUI.click(findTestObject('RDB/Menu/Air_Tariff_Submenu'))

		WebUI.delay(1)

		WebUI.scrollToElement(findTestObject('RDB/Agility_Tariff/Air/List_Page/Upload_Button'), 10)

		WebUI.click(findTestObject('RDB/Agility_Tariff/Air/List_Page/Upload_Button'))
	}
}
