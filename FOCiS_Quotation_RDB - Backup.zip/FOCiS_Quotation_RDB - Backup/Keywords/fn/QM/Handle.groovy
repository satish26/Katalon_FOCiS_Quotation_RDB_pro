package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebDriver
import org.openqa.selenium.NoAlertPresentException;
import com.kms.katalon.core.webui.driver.DriverFactory

public class Handle {

	// http://www.automationtesting.co.in/2014/01/webdriver-verify-if-javascript-alert-is.html
	public static WebDriver driver;

	@Keyword
	public static boolean isAlertPresent(){
		WebUI.delay(1)
		driver = DriverFactory.getWebDriver()
		try{
			driver.switchTo().alert();
			return true;
		}catch(NoAlertPresentException ex){
			return false;
		}
	}





	@Keyword
	public static void dynamic_Alert(){

		WebUI.delay(1)

		if(isAlertPresent()){

			WebUI.acceptAlert()
			WebUI.delay(2)

		}




	}///
}



















































/*try {
 WebUI.waitForAlert(3, FailureHandling.OPTIONAL)
 WebUI.acceptAlert(FailureHandling.OPTIONAL)	
 } catch (Exception e) {
 e.printStackTrace()
 }
 */


/*boolean b=WebUI.verifyAlertPresent(5)
 println b
 if (b) {
 WebUI.delay(1)
 WebUI.acceptAlert()
 WebUI.delay(2)
 WebUI.waitForPageLoad(300)
 WebUI.waitForJQueryLoad(300)
 }*/

/*	try {
 WebUI.delay(1)
 //System.err.println('Alert Present: ' + WebUI.verifyAlertPresent(3))
 if (WebUI.verifyAlertPresent(2)) {///
 System.err.println('Alert Present: ' + WebUI.verifyAlertPresent(2))
 WebUI.delay(1)
 WebUI.acceptAlert()
 WebUI.delay(2)
 WebUI.waitForPageLoad(300)
 WebUI.waitForJQueryLoad(300)
 }////
 } catch (Exception e) {
 //System.err.println('Alert Present: ' + WebUI.verifyAlertPresent(3))
 e.printStackTrace() 
 }
 }
 }*/
