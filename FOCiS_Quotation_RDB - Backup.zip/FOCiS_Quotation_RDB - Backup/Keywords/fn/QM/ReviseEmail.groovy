package fn.QM

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.JavascriptExecutor
import internal.GlobalVariable
import com.kms.katalon.core.webui.driver.DriverFactory
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver

public class ReviseEmail {

	public static WebDriver driver;


	@Keyword
	public void searchQuoteNo(String quoteNo){

		driver = DriverFactory.getWebDriver()
		WebUI.delay(4)

		boolean text = driver.findElements(By.xpath("//*[contains(text(),'"+quoteNo+"')]")).size() >= 1;

		System.err.println("//*[contains(text(),'"+quoteNo+"')]")

		int timeBound = 0

		while (!text && timeBound<=60) {
			WebUI.delay(4)
			//WebUI.click(findTestObject('Quotation/WebMail/UnreadMail'), 300)
			driver.findElement(By.xpath("//span[text()='Unread']")).click();  // Causing Problem
			WebUI.delay(1)
			timeBound= timeBound+5
			text = driver.findElements(By.xpath("//*[contains(text(),'"+quoteNo+"')]")).size() >= 1;
		}


		driver.findElement(By.xpath("//*[contains(text(),'"+quoteNo+"')]")).click()

		WebUI.delay(2)

		'Take Screenshot of \'Quotation Email\' to Customer'
		WebUI.takeScreenshot()

		WebUI.scrollToElement(findTestObject('Quotation/WebMail/Hyperlink'), 5)
		WebUI.focus(findTestObject('Quotation/WebMail/Hyperlink'))

		WebUI.delay(2)

		//Capturing Review and Accept hyperlink Url and navigate to link because clicking on hyperlink is not working in IE Browser
		String ReviewAndAcceptUrl =	WebUI.getAttribute(findTestObject('Quotation/WebMail/Hyperlink'), 'href')

		println (ReviewAndAcceptUrl)

		WebUI.navigateToUrl(ReviewAndAcceptUrl)
		//	WebElement element = WebUiCommonHelper.findWebElement(findTestObject('Quotation/WebMail/Hyperlink'),30)
		//	WebUI.executeJavaScript("arguments[0].click", Arrays.asList(element))
		//JavascriptExecutor executor = (JavascriptExecutor)driver
		//executor.executeScript("arguments[0].click();", driver.findElement(By.xpath("//a[contains(.,'Please click here for your review and acceptance')]")))


		WebUI.delay(1)
		//	WebUI.click(findTestObject('Quotation/WebMail/Hyperlink'))

		WebUI.delay(2)

		//	WebUI.switchToWindowIndex(1)

		WebUI.waitForPageLoad(300)

		WebUI.delay(1)

		'Take Screenshot of \'Quotation Email\' to Customer'
		WebUI.takeScreenshot()

		WebUI.waitForElementClickable(findTestObject('Quotation/WebMail/Revise'), 30)

		//	WebUI.click(findTestObject('Quotation/WebMail/Accept1'))     // Approve MQ

		//	WebUI.setText(findTestObject('Quotation/WebMail/CustomerComments'), 'NAZ AUTOMATION TEST')  // Add Comments

		//	WebUI.delay(1)

		'Take Screenshot of \'Quotation Approval\''
		//	WebUI.takeScreenshot()

		//	Thread.sleep(250);

		//WebUI.click(findTestObject('Quotation/WebMail/Accept2'))     // Approve MQ

		WebUI.delay(1)

		WebUI.click(findTestObject('Quotation/WebMail/Revise'))  // Reject MQ

		WebUI.selectOptionByLabel(findTestObject('Quotation/WebMail/Select_Revision_Reason'), 'Others', false)

		WebUI.waitForElementVisible(findTestObject('Quotation/WebMail/Revision_Comments'), 30)

		WebUI.setText(findTestObject('Quotation/WebMail/Revision_Comments'), 'Automation')

		WebUI.waitForElementVisible(findTestObject('Quotation/WebMail/Revise_Button'), 30)

		WebUI.click(findTestObject('Quotation/WebMail/Revise_Button'))

		//	WebUI.closeWindowIndex(1)

		//	WebUI.switchToDefaultContent()

		WebUI.delay(2)

	}
}


