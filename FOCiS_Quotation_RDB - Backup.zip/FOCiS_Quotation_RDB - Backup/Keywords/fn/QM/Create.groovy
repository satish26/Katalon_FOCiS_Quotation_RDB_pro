package fn.QM

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import java.util.concurrent.TimeUnit;
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


public class Create {

	public static WebDriver driver;

	@Keyword
	public static void mutiQuote(){

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.waitForElementPresent(findTestObject('Quotation/QM_ListPage/btn_Create Multi-Quote'), 300)
		WebUI.waitForElementClickable(findTestObject('Quotation/QM_ListPage/btn_Create Multi-Quote'), 300)

		WebUI.scrollToElement(findTestObject('Quotation/QM_ListPage/btn_Create Multi-Quote'), 30)

		Thread.sleep(500)

		WebUI.click(findTestObject('Quotation/QM_ListPage/btn_Create Multi-Quote'))

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)
	}


	@Keyword
	public static void singleQuote(){

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Create_Single_Quote'), 300)
		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Create_Single_Quote'), 300)

		WebUI.scrollToElement(findTestObject('Quotation/SQ/Create_Single_Quote'), 30)

		Thread.sleep(500)

		WebUI.click(findTestObject('Quotation/SQ/Create_Single_Quote'))

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)
	}


	@Keyword
	public static void MQ_with_AgilityTariff(){

		WebUI.delay(2)

		WebUI.click(findTestObject('Quotation/MQ/CarrierSearch/btn_Add_Agility_Tariff'))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		if (WebUI.getText(findTestObject('Quotation/MQ/TariffSearch/Product')).equals("Ocean Freight")) {
			APOR_Ocean()
		}



		WebUI.takeScreenshot()

		WebUI.delay(1)

		WebUI.scrollToElement(findTestObject('Quotation/MQ/TariffSearch/Search_Agility_Tariff'), 30)
		WebUI.click(findTestObject('Quotation/MQ/TariffSearch/Search_Agility_Tariff'))

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.takeScreenshot()

		WebUI.scrollToElement(findTestObject('Quotation/MQ/TariffSearch/Generate_Quote_with_Agility_Tariff'), 30)
		WebUI.click(findTestObject('Quotation/MQ/TariffSearch/Generate_Quote_with_Agility_Tariff'))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)
		WebUI.delay(1)
	}


	///
	public static void APOR_Ocean(){

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)
		driver = DriverFactory.getWebDriver()

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		List<WebElement> APOR_list = driver.findElements(By.xpath("//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr/td[1]"));
		List<WebElement> APOD_list = driver.findElements(By.xpath("//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr/td[4]"));

		System.out.println("MOP Size: "+APOR_list.size());
		System.out.println("MDP Size: "+APOD_list.size());


		for (int i = 0; i < APOR_list.size(); i++)
		{
			// Port of Loading CELL
			String xp_POL="//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr["+(i+1)+"]/td[2]";
			System.out.println("Xpath of Port of Loading: "+xp_POL);

			// Port of Discharge CELL  ------>
			String xp_POD="//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr["+(i+1)+"]/td[4]";
			System.out.println("Xpath of Port of Delivery: "+xp_POD);

			// Agility Place of Receipt	CELL
			String xp_APOR_Name ="//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr["+(i+1)+"]/td[1]/div/input";
			System.out.println("Xpath of Agility Place of Receipt: "+xp_APOR_Name);

			// Agility Place of Delivery	CELL  ------>
			String xp_APOD_Name ="//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr["+(i+1)+"]/td[5]/div/input";
			System.out.println("Xpath of Agility Place of Delivery: "+xp_APOD_Name);

			System.out.println(driver.findElement(By.xpath(xp_POL)).getText()); // getText  Port of Loading
			System.out.println(driver.findElement(By.xpath(xp_POD)).getText()); // getText  Port of Discharge

			String xp_POL_Name=driver.findElement(By.xpath(xp_POL)).getText();  // DOES NOT WORK.

			System.out.println(xp_POL_Name);

			String POR=driver.findElement(By.xpath(xp_POL)).getText();
			String POD=driver.findElement(By.xpath(xp_POD)).getText();

			//String xp_APOR_Name="//table[@class='table table-bordered table-condensed table-condensed-form']/tbody/tr["+(i+1)+"]/td[1]/div/input"; // working with input tag in the end,


			// During First Iteration 'get attribute: value' will not fetch any text since initially it is empty.
			System.out.println("value NAZ"+driver.findElement(By.xpath(xp_APOR_Name)).getAttribute("value")+"EER"); // working
			System.out.println("value NAZ"+driver.findElement(By.xpath(xp_APOD_Name)).getAttribute("value")+"EER"); // working ------>


			String Str=driver.findElement(By.xpath(xp_APOR_Name)).getAttribute("value");
			String Str2=driver.findElement(By.xpath(xp_APOD_Name)).getAttribute("value");  // ------>

			System.out.println(i+"AAA"+Str.trim());
			System.out.println(i+"AAA"+Str2.trim()); // ------>

			/*//ExtractLastWord_in_String	 - But it doesn't work in all scenrio.  EG: AEARP - Ahmed Bin Rashid Port
			 POR = POR.substring(POR.lastIndexOf(" ")+1); //Will work in case of EG: INMAA - Chennai
			 System.out.println(POR);*/


			//  "AEARP - Ahmed Bin Rashid Port"    from this string extract  only  Ahmed Bin Rashid Port by splitting based on " - "

			String[] APOR_SPLIT = POR.split(" - ");
			String APOR_SPLIT_2 = APOR_SPLIT[1];
			POR=APOR_SPLIT_2;
			System.out.println(POR);

			// ------------------------------->

			String[] APOD_SPLIT = POD.split(" - ");
			String APOD_SPLIT_2 = APOD_SPLIT[1];
			POD=APOD_SPLIT_2;
			System.out.println(POD);

			System.out.println("--------"+POR+"###"+Str.trim());
			System.out.println("--------"+POD+"###"+Str2.trim());


			if(!POR.equals(Str.trim())){

				driver.findElement(By.xpath(xp_APOR_Name)).click();
				driver.findElement(By.xpath(xp_APOR_Name)).clear();
				driver.findElement(By.xpath(xp_APOR_Name)).sendKeys(POR);  // Key in 'Port of Loading' into 'Agility Place of Receipt'
				Thread.sleep(1000L);


				driver.findElement(By.partialLinkText(POR)).click(); // Clik the auto-suggestion partial text.

			}


			// ------------------------------->



			if(!POD.equals(Str2.trim())){

				driver.findElement(By.xpath(xp_APOD_Name)).click();
				driver.findElement(By.xpath(xp_APOD_Name)).clear();
				driver.findElement(By.xpath(xp_APOD_Name)).sendKeys(POD);  // Key in 'Port of Loading' into 'Agility Place of Delivery'
				Thread.sleep(1000L);


				driver.findElement(By.partialLinkText(POD)).click(); // Clik the auto-suggestion partial text.

			}

		}




	}  ////

}
