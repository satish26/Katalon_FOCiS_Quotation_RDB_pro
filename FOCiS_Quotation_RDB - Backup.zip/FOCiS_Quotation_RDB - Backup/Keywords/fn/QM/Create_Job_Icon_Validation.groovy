package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.Keys as Keys

public class Create_Job_Icon_Validation {

	@Keyword
	public void ValidateCreateJobIcon(String QuoteStatus) {

		WebUI.waitForElementClickable(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), 300)

		'Set text for search SQ'
		WebUI.setText(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), 'QT-  ')

		'Select quote with status drafted'
		WebUI.selectOptionByLabel(findTestObject('Quotation/QM_ListPage/Select_Status'), QuoteStatus, false)

		'Enter Backspace'
		WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

		WebUI.delay(1)

		'Enter Backspace'
		WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

		WebUI.delay(1)

		'Wait until page is loaded'
		fn.QM.Wait_For.page_loading()

		WebUI.delay(1)

		'take screenshot for SQ quote result'
		WebUI.takeScreenshot()

		'Wait for Assign Job number Icon to be visible'
		WebUI.waitForElementVisible(findTestObject('Quotation/QM_ListPage/Create_Job'), 60)

		WebUI.click(findTestObject('Quotation/QM_ListPage/Create_Job'))

		'Wait for Assign Job number Icon to be visible'
		WebUI.waitForElementVisible(findTestObject('Quotation/QM_ListPage/Create_Job_Label'), 60)

		WebUI.click(findTestObject('Quotation/QM_ListPage/Create_Job_Cancel_Button'))
	}
}
