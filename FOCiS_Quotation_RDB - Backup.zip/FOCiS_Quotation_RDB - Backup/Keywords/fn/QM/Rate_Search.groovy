package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.WebDriver

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.support.ui.WebDriverWait as WebDriverWait
import org.openqa.selenium.By as By
import org.openqa.selenium.support.ui.ExpectedConditions as ExpectedConditions

public class Rate_Search {

	WebDriver driver = DriverFactory.getWebDriver()
	public static WebDriverWait wait = null

	@Keyword
	public void Origin_Destination_Port(String port) {
		WebUI.waitForJQueryLoad(60)

		'Set port text'
		WebUI.setText(findTestObject('Quotation/MQ/Port_Country_Search/search_port_or_country'), port)

		//	WebUI.waitForJQueryLoad(60)

		wait = new WebDriverWait(driver, 60)

		'Wait for searched port to be visible'
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[text()='"+port+"']")))

		WebUI.takeScreenshot()

		'Click to searched port'
		driver.findElement(By.xpath("//*[text()='"+port+"']")).click()
	}
}
