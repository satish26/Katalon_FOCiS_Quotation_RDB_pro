package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import java.awt.List

import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.By;

public class Add_new_International_Freight {

	public static WebDriver driver;

	@Keyword
	public void addNewInternationalFreight() {
		driver = DriverFactory.getWebDriver()

		if (WebUI.waitForElementPresent(findTestObject('Quotation/SQ/International_Freight_Tab/First_International_Freight_Checkbox'), 5)) {

			int RowCount = driver.findElements(By.xpath("//table[@id='carriertable']/tbody/tr")).size()
			println (RowCount)

			if (RowCount>=1) {

				WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/First_International_Freight_Checkbox'))
				WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Save_Button'))

				WebUI.waitForPageLoad(200)
				WebUI.waitForJQueryLoad(200)

				WebUI.waitForElementVisible(findTestObject('Quotation/SQ/International_Freight_Tab/View_First_Charges'), 60)

				WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/View_First_Charges'))

				WebUI.waitForElementVisible(findTestObject('Quotation/SQ/International_Freight_Tab/First_Sell_Rate'), 60)

				WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/First_Sell_Rate'), '-1')

				WebUI.takeScreenshot()

				'Click \'Save and Continue\' in Quote_Summary_tab:  Navigates to Quote Summary Page.'
				WebUI.click(findTestObject('Quotation/SQ/Save_and_Continue'))

				WebUI.waitForPageLoad(200)
				WebUI.waitForJQueryLoad(200)
			}
		}
		else {
			'Click on  \'Add New International Freight\' button'
			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_International_Freight_Button'))

			'Wait until page is loaded'
			WebUI.waitForPageLoad(300)

			WebUI.delay(2)

			'Wait until Add New Carrier Information popup is Visible'
			WebUI.waitForElementVisible(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Carrier_Information_Frame'),
					300)

			'Switch to Add New Carrier Information Popup/Frame '
			WebUI.switchToFrame(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Carrier_Information_Frame'),
					300)

			WebUI.delay(2)

			'Take Screenshot of Add New International Freight popup'
			WebUI.takeScreenshot()

			'Click \'Save and Continue\' in Add New Carrier Popup'
			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Save_and_Continue'))

			WebUI.delay(2)

			WebUI.waitForPageLoad(200)
			WebUI.waitForJQueryLoad(200)

			WebUI.delay(2)

			'Wait until \'Save_Rate_And_Close_Button\' is Visible'
			WebUI.waitForElementVisible(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Save_Rate_And_Close_Button'),
					5)

			'Wait until \'Save_Rate_And_Close_Button\' is present'
			WebUI.waitForElementPresent(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Save_Rate_And_Close_Button'),
					3)

			'Wait until \'Save_Rate_And_Close_Button\' is clickable '
			WebUI.waitForElementClickable(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Save_Rate_And_Close_Button'),
					2)

			'Take Screenshot of Air Freight charge screen'
			WebUI.takeScreenshot()

			'----------->>>>>>> Key in SLAB Rates'
			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_1'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_1'), '-10')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_2'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_2'), '2')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_3'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_3'), '3')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_4'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_4'), '4')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_5'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_5'), '5')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_6'))

			WebUI.setText(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Air/Sell_Rate_Row_6'), '6')

			WebUI.click(findTestObject('Quotation/SQ/International_Freight_Tab/Add_New_Carrier_Popup/Save_Rate_And_Close_Button'))

			WebUI.scrollToElement(findTestObject('Quotation/SQ/Save_and_Continue'), 60)

			WebUI.delay(1)

			'Take Screenshot of Air Freight Slab after keying in value'
			WebUI.takeScreenshot()

			'Wait until \'Save_and_Continue_Button\' is Visible'
			WebUI.waitForElementVisible(findTestObject('Quotation/SQ/Save_and_Continue'), 30)

			'Click \'Save and Continue\' in Quote_Summary_tab:  Navigates to Quote Summary Page.'
			WebUI.click(findTestObject('Quotation/SQ/Save_and_Continue'))

			WebUI.waitForPageLoad(200)
			WebUI.waitForJQueryLoad(200)
		}
	}

	@Keyword
	public void MQDeleteRoutes() {
		driver = DriverFactory.getWebDriver()

		int RowCount = driver.findElements(By.xpath("//input[@class='checkboxRoute']")).size()
		println (RowCount)

		for(int route = 1; route <= RowCount ;route ++ ) {
			driver.findElement(By.xpath("(//input[@class='checkboxRoute'])["+route+"]")).click()
		}
	}
}
