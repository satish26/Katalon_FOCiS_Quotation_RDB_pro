package fn.QM

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.By;
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class Search_Quote {

	WebDriver driver = DriverFactory.getWebDriver()
	public static final String testApp = GlobalVariable.testApp;
	public static String URL = "";

	@Keyword
	public void no(String quoteNo) throws Throwable {

		search(quoteNo)
	}



	public void search(String quoteNo){

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.waitForElementClickable(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), 300)

		WebUI.setText(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), quoteNo)

		WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

		WebUI.delay(1)

		WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

		WebUI.delay(1)

		WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

		WebUI.delay(1)

		boolean text = driver.findElements(By.xpath("//td[contains(text(),'"+quoteNo+"')]")).size() == 1;
		while (!text) {

			driver.findElement(By.xpath("//input[@id='gs_QUOTATIONNUMBER']")).clear();
			driver.findElement(By.xpath("//input[@id='gs_QUOTATIONNUMBER']")).sendKeys(quoteNo);
			WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

			WebUI.delay(1)

			WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

			WebUI.delay(1)

			WebUI.sendKeys(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), Keys.chord(Keys.BACK_SPACE))

			WebUI.delay(1)

			text = driver.findElements(By.xpath("//td[contains(text(),'"+quoteNo+"')]")).size() == 1;
		}

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)
		WebUI.delay(1)
	}
}
