package fn.QM

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.By;
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.WebDriver

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

public class CustomerLogIn {


	public static final String testApp = GlobalVariable.testApp;
	public static String URL = "";



	@Keyword
	public static void logIN(){

		println ("***********")

		// Firstly I am logging into demo site to HACK/AVOID/BYPASS Authentication popup being open when you click on hyperlink in webmail
		// Since demo site needs Authentication.

		if (testApp.replace(" ", "").toLowerCase().equals("demo"))
		{
			URL = "https://logistics%5ctopuser2_mel:password@focisdemo.agility.com/";
			WebUI.openBrowser(URL)
			System.err.println("-----NAZ LOG: ----- "+URL);
			enter()
		}

		else if (testApp.replace(" ", "").toLowerCase().equals("demo173"))
		{
			URL = "http://logistics%5ctopuser2_mel:password@10.201.69.173:222/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			enter()

		}

		else if (testApp.replace(" ", "").toLowerCase().equals("demo174"))
		{
			URL = "http://logistics%5ctopuser2_mel:password@10.201.69.174:222/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			enter()

		}

		else {
			WebUI.openBrowser('')
			enter()
		}

	}


	public static void enter(){


		WebUI.navigateToUrl('https://mailkw.agility.com/owa/')

		WebUI.waitForPageLoad(300)

		WebUI.maximizeWindow()

		WebUI.setText(findTestObject('Quotation/WebMail/UserName'), GlobalVariable.CustomerName)

		WebUI.setText(findTestObject('Quotation/WebMail/Password'), GlobalVariable.CustomerPassword)

		WebUI.click(findTestObject('Quotation/WebMail/SignIn'))

		WebUI.waitForPageLoad(300)

	}



}
