package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.Keys as Keys
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords


import org.openqa.selenium.By
import org.openqa.selenium.JavascriptExecutor
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import com.kms.katalon.core.webui.driver.DriverFactory

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

public class Select {



	@Keyword
	public void Agility_Place_of_Receipt(String APOR) throws Throwable {

		WebUI.setText(findTestObject('Quotation/SQ/Quote_Info_tab/APOR'), APOR)

		WebUI.waitForElementVisible(findTestObject('Quotation/SQ/Quote_Info_tab/APOR_Search_Result'), 15)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Quote_Info_tab/APOR_Search_Result'), 10)

		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Quote_Info_tab/APOR_Search_Result'), 10)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Info_tab/APOR_Search_Result'))

		WebUI.sendKeys(findTestObject('Quotation/SQ/Quote_Info_tab/APOR'), Keys.chord(Keys.TAB))
	}



	@Keyword
	public void Origin_Port(String port) throws Throwable {
		WebUI.setText(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port'), port)

		WebUI.waitForElementVisible(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port_Search_Result'), 15)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port_Search_Result'), 10)

		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port_Search_Result'), 10)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port_Search_Result'))

		WebUI.sendKeys(findTestObject('Quotation/SQ/Quote_Info_tab/Origin_Port'), Keys.chord(Keys.TAB))
	}




	@Keyword
	public void Agility_Place_of_Delivery(String APOD) throws Throwable {

		WebUI.setText(findTestObject('Quotation/SQ/Quote_Info_tab/APOD'), APOD)

		WebUI.waitForElementVisible(findTestObject('Quotation/SQ/Quote_Info_tab/APOD_Search_Result'), 15)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Quote_Info_tab/APOD_Search_Result'), 10)

		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Quote_Info_tab/APOD_Search_Result'), 10)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Info_tab/APOD_Search_Result'))

		WebUI.sendKeys(findTestObject('Quotation/SQ/Quote_Info_tab/APOD'), Keys.chord(Keys.TAB))
	}



	@Keyword
	public void Destination_Port(String port) throws Throwable {


		WebUI.setText(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port'), port)

		WebUI.waitForElementVisible(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port_Search_Result'), 15)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port_Search_Result'), 10)

		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port_Search_Result'), 10)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port_Search_Result'))

		WebUI.sendKeys(findTestObject('Quotation/SQ/Quote_Info_tab/Destination_Port'), Keys.chord(Keys.TAB))
	}



	@Keyword
	public static void Customer(){

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(1)

		WebUI.scrollToElement(findTestObject('Quotation/MQ/QuoteSummaryPage/btn_CustomerNamePopup'), 60)

		WebUI.click(findTestObject('Quotation/MQ/QuoteSummaryPage/btn_CustomerNamePopup'))

		WebUI.setText(findTestObject('Quotation/MQ/QuoteSummaryPage/searchAddress'), 'z AES TEST STAKEHOLDER')

		WebUI.sendKeys(findTestObject('Quotation/MQ/QuoteSummaryPage/searchAddress'), Keys.chord(Keys.ENTER))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(2)

		WebUI.waitForElementPresent(findTestObject('Quotation/MQ/QuoteSummaryPage/selectAddress'), 30)

		WebUI.waitForElementClickable(findTestObject('Quotation/MQ/QuoteSummaryPage/selectAddress'), 60)

		WebUI.click(findTestObject('Quotation/MQ/QuoteSummaryPage/selectAddress'))

		WebUI.delay(1)
	}


	@Keyword
	public static void Customer_SQ(){

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(1)

		WebUI.scrollToElement(findTestObject('Quotation/SQ/Quote_Summary_Tab/Customer_Name_Popup'), 60)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Summary_Tab/Customer_Name_Popup'))

		WebUI.waitForJQueryLoad(60)

		WebUI.setText(findTestObject('Quotation/SQ/Quote_Summary_Tab/Search_Customer'), 'z AES TEST STAKEHOLDER')

		WebUI.sendKeys(findTestObject('Quotation/SQ/Quote_Summary_Tab/Search_Customer'), Keys.chord(Keys.ENTER))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(2)

		WebUI.waitForElementPresent(findTestObject('Quotation/SQ/Quote_Summary_Tab/Select_Customer'), 30)

		WebUI.waitForElementClickable(findTestObject('Quotation/SQ/Quote_Summary_Tab/Select_Customer'), 60)

		WebUI.click(findTestObject('Quotation/SQ/Quote_Summary_Tab/Select_Customer'))

		WebUI.delay(1)
	}
}


