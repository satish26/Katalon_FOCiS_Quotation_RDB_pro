package fn.QM

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

public class AssignJobNo {



	@Keyword
	public static void SQ() throws Throwable {
		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.click(findTestObject('Quotation/QM_ListPage/AssignJobNo'))

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.waitForElementVisible(findTestObject('Quotation/QM_ListPage/AssignJobNoFrame'),300)

		WebUI.switchToFrame(findTestObject('Quotation/QM_ListPage/AssignJobNoFrame'), 300)

		WebUI.delay(1)

		WebUI.setText(findTestObject('Quotation/QM_ListPage/SQ_Job_No'), getRndNumberAsString())

		WebUI.takeScreenshot()

		WebUI.delay(1)

		WebUI.click(findTestObject('Quotation/QM_ListPage/Save_SQ_Job_No_Button'))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(1)

		WebUI.takeScreenshot()

		WebUI.delay(1)

		WebUI.switchToDefaultContent()

		WebUI.click(findTestObject('Quotation/QM_ListPage/CloseJobDetailsPopUp'))

		WebUI.delay(2)
	}


	@Keyword
	public static void MQ() throws Throwable {
		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.click(findTestObject('Quotation/QM_ListPage/AssignJobNo'))

		WebUI.waitForPageLoad(300)
		WebUI.waitForJQueryLoad(300)

		WebUI.waitForElementVisible(findTestObject('Quotation/QM_ListPage/AssignJobNoFrame'),300)

		WebUI.switchToFrame(findTestObject('Quotation/QM_ListPage/AssignJobNoFrame'), 300)

		WebUI.delay(1)

		WebUI.setText(findTestObject('Quotation/QM_ListPage/JobNo'), getRndNumberAsString())

		WebUI.takeScreenshot()

		WebUI.delay(1)

		WebUI.click(findTestObject('Quotation/QM_ListPage/SaveJobDetails'))

		WebUI.waitForPageLoad(300)

		WebUI.waitForJQueryLoad(300)

		WebUI.delay(1)

		WebUI.scrollToElement(findTestObject('Quotation/QM_ListPage/SaveJobDetails'), 30)

		WebUI.takeScreenshot()

		WebUI.delay(1)

		WebUI.switchToDefaultContent()

		WebUI.click(findTestObject('Quotation/QM_ListPage/CloseJobDetailsPopUp'))

		WebUI.delay(2)
	}

	@Keyword
	public void AssignTemplateName() {
		WebUI.setText(findTestObject('Quotation/Quotation_Template/Quotation_Template_Details_Page/Template_Name_Textbox'), getRndNumberAsString())
	}

	@Keyword
	public static String getRndNumberAsString() {
		Random random=new Random();
		int randomNumber=0;
		boolean loop=true;
		while(loop) {
			randomNumber=random.nextInt();
			if(Integer.toString(randomNumber).length()==10 && !Integer.toString(randomNumber).startsWith("-")) {
				loop=false;
			}
		}
		GlobalVariable.AssignJobNumber = Integer.toString(randomNumber)
		return Integer.toString(randomNumber);
	}

	@Keyword
	public static String getRandomQuoteValidityAsString(int MaxValue) {
		Random random=new Random();
		int randomNumber=1;

		randomNumber=randomNumber + random.nextInt(MaxValue);
		//GlobalVariable.AssignJobNumber = Integer.toString(randomNumber)
		return Integer.toString(randomNumber);
	}
}
