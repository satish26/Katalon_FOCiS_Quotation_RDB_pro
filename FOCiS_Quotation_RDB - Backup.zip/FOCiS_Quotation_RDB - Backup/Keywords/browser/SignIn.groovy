package browser

import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import com.kms.katalon.core.webui.driver.DriverFactory

/**
 *
 *
 * @author Nazeer Mohammed
 * NaMohammed@agility.com
 *
 *
 */


public class SignIn {

	public String testApp = GlobalVariable.testApp;
	public static String URL = "";
	//System.err.println(testApp);

	@Keyword
	public void As(String User, String password) throws Throwable {
		// -------------------------------- SIT SITE-------------------------------------------//

		if (testApp.replace(" ", "").toLowerCase().equals("sit"))
		{
			URL = "http://"+GlobalVariable.SIT+"/login.aspx";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Username'), User)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Password'), 'q')
			WebUI.click(findTestObject('Login_SIT_AGILE/Login_SignIn_Button'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- WebApp SITE-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("webapp"))
		{
			URL = "http://"+GlobalVariable.WebApp+"/login.aspx";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Username'), User)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Password'), 'q')
			WebUI.click(findTestObject('Login_SIT_AGILE/Login_SignIn_Button'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- AGILE SITE-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("agile"))
		{
			URL = "http://"+GlobalVariable.AGILE+"/login.aspx";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(30)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Username'), User)
			WebUI.setText(findTestObject('Login_SIT_AGILE/Login_Password'), 'q')
			WebUI.click(findTestObject('Login_SIT_AGILE/Login_SignIn_Button'))
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- DEMO SITE-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("demo"))
		{
			URL = "https://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}


		// -------------------------------- DEMO  173-------------------------------------------//

		else if (testApp.replace(" ", "").toLowerCase().equals("demo173"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO173+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- DEMO  174-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("demo174"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.DEMO174+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  45-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live45"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE45+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  46-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live46"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE46+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  181-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live181"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE181+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE  182-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live182"))
		{
			URL = "http://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE182+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()

		}

		// -------------------------------- LIVE SITE-------------------------------------------//
		else if (testApp.replace(" ", "").toLowerCase().equals("live"))
		{

			URL = "https://logistics%5c" + User + ":" + password + "@"+GlobalVariable.LIVE+"/";
			System.err.println("-----NAZ LOG: ----- "+URL);
			WebUI.openBrowser(URL)
			WebUI.maximizeWindow()
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			HomePageCondition()
		}


		else {

			System.err.println("NAZ LOG: FOCiS TEST APP DECLARED IN INCORRECT");
		}

	}

	public void HomePageCondition()
	{
		if (WebUI.waitForElementPresent(findTestObject('Quotation/QM_ListPage/searchQuoteNo'), 3))
		{
			System.err.println("Quote List Home Page");
		}
		else
		{
			System.err.println("Banner Home Page");

			'Click to Quotation Tab'
			WebUI.click(findTestObject('Quotation/Menu/Quotation'))

			'Click to Manage Quotation Tab'
			WebUI.click(findTestObject('Quotation/Menu/Manage_Quotation'))

			'Wait until page is loaded'
			WebUI.waitForPageLoad(300)
			WebUI.waitForJQueryLoad(300)

			'Take Screenshot of \'Quotation List Page\' '
			WebUI.takeScreenshot()
		}
	}

}


