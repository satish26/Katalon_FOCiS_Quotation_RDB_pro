package browser

import java.text.SimpleDateFormat;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.kms.katalon.core.annotation.Keyword


public class WriteToExcel {

	@Keyword
	def void writeToExcel(String excelFileName, String sheetName,int iRow, int iCell, String iText ){

		String fileName=excelFileName
		fileName=System.getProperty("user.dir")+"\\Data Files\\"+fileName+'.xlsx'
		System.err.println(fileName)

		FileInputStream file = new FileInputStream (new File(fileName))
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet(sheetName)

		sheet.autoSizeColumn(0)
		sheet.autoSizeColumn(1)
		sheet.autoSizeColumn(2)

		//Write data to excel'
		Row oRow;
		oRow = sheet.getRow(iRow-1);
		if(oRow == null){
			sheet.createRow(iRow-1);
			oRow = sheet.getRow(iRow-1);
		}
		Cell oCell;
		oCell = oRow.getCell(iCell - 1);
		if(oCell == null ){
			oRow.createCell(iCell - 1);
			oCell = oRow.getCell(iCell - 1);
		}
		oCell.setCellValue(iText);
		FileOutputStream outFile =new FileOutputStream(new File(fileName));
		workbook.write(outFile);
		outFile.close();

		Thread.sleep(500);  // It is important to delay
	}

	@Keyword
	public static String createExcel_Sheet(String excelFileName,String sheetName) throws IOException, InvalidFormatException, Throwable
	{
		// ***************************Add a sheet into Existing  workbook***********************************************

		excelFileName=System.getProperty("user.dir")+"\\Data Files\\"+excelFileName+'.xlsx'

		Date date = new Date();
		SimpleDateFormat customDate;

		customDate = new SimpleDateFormat("dd-MMM-yy (EEE) hh;mm;ss a");
		String dateOutput = customDate.format(date);
		System.out.println(dateOutput); // Output: 04-Aug-18 (Sat) 06;37;31 PM

		sheetName = sheetName + " " + dateOutput;

		System.err.println("New Sheet Name is:  "+ sheetName); // Output : [String sheetname] 04-Aug-18 (Sat) 06;37;31 PM

		FileInputStream fileinput = new FileInputStream(excelFileName);
		XSSFWorkbook workboook = new XSSFWorkbook(fileinput);

		workboook.createSheet(sheetName);

		FileOutputStream fileOut = new FileOutputStream(excelFileName);
		workboook.write(fileOut);
		fileOut.close();
		System.out.println("File is written successfully");

		Thread.sleep(1000L);  // It is important to delay

		return sheetName;

	}
}
