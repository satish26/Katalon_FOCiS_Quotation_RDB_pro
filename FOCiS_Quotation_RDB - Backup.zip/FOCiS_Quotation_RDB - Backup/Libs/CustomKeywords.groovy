
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import java.util.List



def static "fn.QM.Create.mutiQuote"() {
    (new fn.QM.Create()).mutiQuote()
}


def static "fn.QM.Create.singleQuote"() {
    (new fn.QM.Create()).singleQuote()
}


def static "fn.QM.Create.MQ_with_AgilityTariff"() {
    (new fn.QM.Create()).MQ_with_AgilityTariff()
}


def static "fn.QM.Quotation_Number.SQQuotationNumber"() {
    (new fn.QM.Quotation_Number()).SQQuotationNumber()
}


def static "fn.RDB.navigateToCarrierContract.OceanFreight_FCL"() {
    (new fn.RDB.navigateToCarrierContract()).OceanFreight_FCL()
}


def static "fn.QM.Add_new_International_Freight.addNewInternationalFreight"() {
    (new fn.QM.Add_new_International_Freight()).addNewInternationalFreight()
}


def static "fn.QM.Add_new_International_Freight.MQDeleteRoutes"() {
    (new fn.QM.Add_new_International_Freight()).MQDeleteRoutes()
}


def static "fn.QM.ApproveEmail.searchQuoteNo"(
    	String quoteNo	) {
    (new fn.QM.ApproveEmail()).searchQuoteNo(
        	quoteNo)
}


def static "fn.QM.ReviseEmail.searchQuoteNo"(
    	String quoteNo	) {
    (new fn.QM.ReviseEmail()).searchQuoteNo(
        	quoteNo)
}


def static "fn.QM.DragAndDropUnique.portCodesFCL"() {
    (new fn.QM.DragAndDropUnique()).portCodesFCL()
}


def static "fn.QM.DragAndDropUnique.portCodesAir"() {
    (new fn.QM.DragAndDropUnique()).portCodesAir()
}


def static "fn.QM.DragAndDropUnique.portCodesLCL"() {
    (new fn.QM.DragAndDropUnique()).portCodesLCL()
}


def static "browser.Alert_Screenshot.AlertScreenshot"(
    	String path	) {
    (new browser.Alert_Screenshot()).AlertScreenshot(
        	path)
}


def static "fn.QM.Handle.isAlertPresent"() {
    (new fn.QM.Handle()).isAlertPresent()
}


def static "fn.QM.Handle.dynamic_Alert"() {
    (new fn.QM.Handle()).dynamic_Alert()
}


def static "fn.QM.Search_Quote_Open.no"(
    	String quoteNo	) {
    (new fn.QM.Search_Quote_Open()).no(
        	quoteNo)
}


def static "fn.QM.Search_Quote_Open.search"(
    	String quoteNo	) {
    (new fn.QM.Search_Quote_Open()).search(
        	quoteNo)
}


def static "fn.QM.ValidateProduct.productType"() {
    (new fn.QM.ValidateProduct()).productType()
}


def static "fn.QM.Search_Quote.no"(
    	String quoteNo	) {
    (new fn.QM.Search_Quote()).no(
        	quoteNo)
}


def static "fn.QM.SignIn.As"(
    	String User	
     , 	String password	) {
    (new fn.QM.SignIn()).As(
        	User
         , 	password)
}


def static "fn.QM.CopyPaste.copy"(
    	String textValue	) {
    (new fn.QM.CopyPaste()).copy(
        	textValue)
}


def static "browser.WriteToExcel.writeToExcel"(
    	String excelFileName	
     , 	String sheetName	
     , 	int iRow	
     , 	int iCell	
     , 	String iText	) {
    (new browser.WriteToExcel()).writeToExcel(
        	excelFileName
         , 	sheetName
         , 	iRow
         , 	iCell
         , 	iText)
}


def static "browser.WriteToExcel.createExcel_Sheet"(
    	String excelFileName	
     , 	String sheetName	) {
    (new browser.WriteToExcel()).createExcel_Sheet(
        	excelFileName
         , 	sheetName)
}


def static "fn.QM.CustomerLogIn.logIN"() {
    (new fn.QM.CustomerLogIn()).logIN()
}


def static "fn.RDB.navigateToOF.AgilityTariff"() {
    (new fn.RDB.navigateToOF()).AgilityTariff()
}


def static "fn.QM.Create_Job_Icon_Validation.ValidateCreateJobIcon"(
    	String QuoteStatus	) {
    (new fn.QM.Create_Job_Icon_Validation()).ValidateCreateJobIcon(
        	QuoteStatus)
}


def static "fn.QM.Search.multiple"(
    	String name	
     , 	String portCode	) {
    (new fn.QM.Search()).multiple(
        	name
         , 	portCode)
}


def static "browser.HighlightElement.run"(
    	TestObject objectto	) {
    (new browser.HighlightElement()).run(
        	objectto)
}


def static "fn.QM.Select.Agility_Place_of_Receipt"(
    	String APOR	) {
    (new fn.QM.Select()).Agility_Place_of_Receipt(
        	APOR)
}


def static "fn.QM.Select.Origin_Port"(
    	String port	) {
    (new fn.QM.Select()).Origin_Port(
        	port)
}


def static "fn.QM.Select.Agility_Place_of_Delivery"(
    	String APOD	) {
    (new fn.QM.Select()).Agility_Place_of_Delivery(
        	APOD)
}


def static "fn.QM.Select.Destination_Port"(
    	String port	) {
    (new fn.QM.Select()).Destination_Port(
        	port)
}


def static "fn.QM.Select.Customer"() {
    (new fn.QM.Select()).Customer()
}


def static "fn.QM.Select.Customer_SQ"() {
    (new fn.QM.Select()).Customer_SQ()
}


def static "fn.RDB.naviageTo.AgilityTariff"() {
    (new fn.RDB.naviageTo()).AgilityTariff()
}


def static "fn.QM.CopyRight.RightText"() {
    (new fn.QM.CopyRight()).RightText()
}


def static "fn.QM.VerifyExpectedAndActualOptionsInDropdown.VerifyExpectedAndActualValue"(
    	TestObject objectto	
     , 	java.util.List<String> listOfOptions	) {
    (new fn.QM.VerifyExpectedAndActualOptionsInDropdown()).VerifyExpectedAndActualValue(
        	objectto
         , 	listOfOptions)
}


def static "fn.QM.AssignJobNo.SQ"() {
    (new fn.QM.AssignJobNo()).SQ()
}


def static "fn.QM.AssignJobNo.MQ"() {
    (new fn.QM.AssignJobNo()).MQ()
}


def static "fn.QM.AssignJobNo.AssignTemplateName"() {
    (new fn.QM.AssignJobNo()).AssignTemplateName()
}


def static "fn.QM.AssignJobNo.getRndNumberAsString"() {
    (new fn.QM.AssignJobNo()).getRndNumberAsString()
}


def static "fn.QM.AssignJobNo.getRandomQuoteValidityAsString"(
    	int MaxValue	) {
    (new fn.QM.AssignJobNo()).getRandomQuoteValidityAsString(
        	MaxValue)
}


def static "fn.QM.Submit_To.QuoteApprover"() {
    (new fn.QM.Submit_To()).QuoteApprover()
}


def static "fn.QM.Submit_To.QuoteApprover_SQ"() {
    (new fn.QM.Submit_To()).QuoteApprover_SQ()
}


def static "fn.QM.Submit_To.RateApprover_SQ"() {
    (new fn.QM.Submit_To()).RateApprover_SQ()
}


def static "browser.SignIn.As"(
    	String User	
     , 	String password	) {
    (new browser.SignIn()).As(
        	User
         , 	password)
}


def static "fn.QM.Rate_Search.Origin_Destination_Port"(
    	String port	) {
    (new fn.QM.Rate_Search()).Origin_Destination_Port(
        	port)
}


def static "fn.QM.Host.details"() {
    (new fn.QM.Host()).details()
}


def static "fn.QM.Host.name"() {
    (new fn.QM.Host()).name()
}


def static "fn.QM.Wait_For.page_loading"() {
    (new fn.QM.Wait_For()).page_loading()
}
