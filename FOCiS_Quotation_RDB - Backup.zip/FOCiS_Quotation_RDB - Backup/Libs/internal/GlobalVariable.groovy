package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : sit;Agile; demo; demo173; demo174; live; live45; live46; live81; live82
Profile DEMO : demo; demo173; demo174
Profile LIVE : live; live45; live46; live81; live82</p>
     */
    public static Object testApp
     
    /**
     * <p></p>
     */
    public static Object CSR_User
     
    /**
     * <p></p>
     */
    public static Object CSR_password
     
    /**
     * <p></p>
     */
    public static Object QT_Approver
     
    /**
     * <p></p>
     */
    public static Object QT_Approver_Password
     
    /**
     * <p></p>
     */
    public static Object Customer_Email_ID
     
    /**
     * <p></p>
     */
    public static Object CustomerPassword
     
    /**
     * <p></p>
     */
    public static Object CustomerName
     
    /**
     * <p></p>
     */
    public static Object row
     
    /**
     * <p></p>
     */
    public static Object SIT
     
    /**
     * <p></p>
     */
    public static Object AGILE
     
    /**
     * <p></p>
     */
    public static Object DEMO
     
    /**
     * <p></p>
     */
    public static Object DEMO173
     
    /**
     * <p></p>
     */
    public static Object DEMO174
     
    /**
     * <p></p>
     */
    public static Object LIVE
     
    /**
     * <p></p>
     */
    public static Object LIVE45
     
    /**
     * <p></p>
     */
    public static Object LIVE46
     
    /**
     * <p>Profile default : Live   Demo</p>
     */
    public static Object Shipa_testApp
     
    /**
     * <p></p>
     */
    public static Object Shipa_Demo
     
    /**
     * <p></p>
     */
    public static Object Shipa_Live
     
    /**
     * <p></p>
     */
    public static Object Shipa_User
     
    /**
     * <p></p>
     */
    public static Object Shipa_Password
     
    /**
     * <p></p>
     */
    public static Object JP_username
     
    /**
     * <p></p>
     */
    public static Object Jp_password
     
    /**
     * <p></p>
     */
    public static Object Agile_XXX
     
    /**
     * <p></p>
     */
    public static Object SQ_No
     
    /**
     * <p></p>
     */
    public static Object MQ_No
     
    /**
     * <p></p>
     */
    public static Object QM_Admin
     
    /**
     * <p></p>
     */
    public static Object QM_Admin_Password
     
    /**
     * <p></p>
     */
    public static Object Document_Number
     
    /**
     * <p></p>
     */
    public static Object AssignJobNumber
     
    /**
     * <p></p>
     */
    public static Object LIVE181
     
    /**
     * <p></p>
     */
    public static Object LIVE182
     
    /**
     * <p></p>
     */
    public static Object Rate_Approver
     
    /**
     * <p></p>
     */
    public static Object Rate_Approver_Password
     
    /**
     * <p></p>
     */
    public static Object WebApp
     
    /**
     * <p></p>
     */
    public static Object SQ_AIR_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_FCL_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_FCL_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_LCL_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_LCL_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_AIR_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_AIR_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_FCL_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_FCL_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_LCL_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object MQ_LCL_Destination_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_AIR_Origin_Port
     
    /**
     * <p></p>
     */
    public static Object SQ_AIR_Agility_Place_Of_Receipt
     
    /**
     * <p></p>
     */
    public static Object SQ_AIR_Agility_Place_Of_Delivery
     
    /**
     * <p></p>
     */
    public static Object SQ_FCL_Agility_Place_Of_Receipt
     
    /**
     * <p></p>
     */
    public static Object SQ_FCL_Agility_Place_Of_Delivery
     
    /**
     * <p></p>
     */
    public static Object SQ_LCL_Agility_Place_Of_Receipt
     
    /**
     * <p></p>
     */
    public static Object SQ_LCL_Agility_Place_Of_Delivery
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            testApp = selectedVariables['testApp']
            CSR_User = selectedVariables['CSR_User']
            CSR_password = selectedVariables['CSR_password']
            QT_Approver = selectedVariables['QT_Approver']
            QT_Approver_Password = selectedVariables['QT_Approver_Password']
            Customer_Email_ID = selectedVariables['Customer_Email_ID']
            CustomerPassword = selectedVariables['CustomerPassword']
            CustomerName = selectedVariables['CustomerName']
            row = selectedVariables['row']
            SIT = selectedVariables['SIT']
            AGILE = selectedVariables['AGILE']
            DEMO = selectedVariables['DEMO']
            DEMO173 = selectedVariables['DEMO173']
            DEMO174 = selectedVariables['DEMO174']
            LIVE = selectedVariables['LIVE']
            LIVE45 = selectedVariables['LIVE45']
            LIVE46 = selectedVariables['LIVE46']
            Shipa_testApp = selectedVariables['Shipa_testApp']
            Shipa_Demo = selectedVariables['Shipa_Demo']
            Shipa_Live = selectedVariables['Shipa_Live']
            Shipa_User = selectedVariables['Shipa_User']
            Shipa_Password = selectedVariables['Shipa_Password']
            JP_username = selectedVariables['JP_username']
            Jp_password = selectedVariables['Jp_password']
            Agile_XXX = selectedVariables['Agile_XXX']
            SQ_No = selectedVariables['SQ_No']
            MQ_No = selectedVariables['MQ_No']
            QM_Admin = selectedVariables['QM_Admin']
            QM_Admin_Password = selectedVariables['QM_Admin_Password']
            Document_Number = selectedVariables['Document_Number']
            AssignJobNumber = selectedVariables['AssignJobNumber']
            LIVE181 = selectedVariables['LIVE181']
            LIVE182 = selectedVariables['LIVE182']
            Rate_Approver = selectedVariables['Rate_Approver']
            Rate_Approver_Password = selectedVariables['Rate_Approver_Password']
            WebApp = selectedVariables['WebApp']
            SQ_AIR_Destination_Port = selectedVariables['SQ_AIR_Destination_Port']
            SQ_FCL_Origin_Port = selectedVariables['SQ_FCL_Origin_Port']
            SQ_FCL_Destination_Port = selectedVariables['SQ_FCL_Destination_Port']
            SQ_LCL_Origin_Port = selectedVariables['SQ_LCL_Origin_Port']
            SQ_LCL_Destination_Port = selectedVariables['SQ_LCL_Destination_Port']
            MQ_AIR_Origin_Port = selectedVariables['MQ_AIR_Origin_Port']
            MQ_AIR_Destination_Port = selectedVariables['MQ_AIR_Destination_Port']
            MQ_FCL_Origin_Port = selectedVariables['MQ_FCL_Origin_Port']
            MQ_FCL_Destination_Port = selectedVariables['MQ_FCL_Destination_Port']
            MQ_LCL_Origin_Port = selectedVariables['MQ_LCL_Origin_Port']
            MQ_LCL_Destination_Port = selectedVariables['MQ_LCL_Destination_Port']
            SQ_AIR_Origin_Port = selectedVariables['SQ_AIR_Origin_Port']
            SQ_AIR_Agility_Place_Of_Receipt = selectedVariables['SQ_AIR_Agility_Place_Of_Receipt']
            SQ_AIR_Agility_Place_Of_Delivery = selectedVariables['SQ_AIR_Agility_Place_Of_Delivery']
            SQ_FCL_Agility_Place_Of_Receipt = selectedVariables['SQ_FCL_Agility_Place_Of_Receipt']
            SQ_FCL_Agility_Place_Of_Delivery = selectedVariables['SQ_FCL_Agility_Place_Of_Delivery']
            SQ_LCL_Agility_Place_Of_Receipt = selectedVariables['SQ_LCL_Agility_Place_Of_Receipt']
            SQ_LCL_Agility_Place_Of_Delivery = selectedVariables['SQ_LCL_Agility_Place_Of_Delivery']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
