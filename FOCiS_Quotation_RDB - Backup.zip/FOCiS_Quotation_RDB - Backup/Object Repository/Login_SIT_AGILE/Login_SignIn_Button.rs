<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Login_SignIn_Button</name>
   <tag></tag>
   <elementGuidId>05ad4237-a916-4b1d-8777-635af775f874</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@Sign In = concat('.//*[@id=' , &quot;'&quot; , 'Login1_LoginButton' , &quot;'&quot; , ']')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>.//*[@id='Login1_LoginButton']</value>
   </webElementProperties>
</WebElementEntity>
