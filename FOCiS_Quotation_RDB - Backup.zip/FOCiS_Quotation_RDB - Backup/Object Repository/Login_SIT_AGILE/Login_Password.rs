<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Login_Password</name>
   <tag></tag>
   <elementGuidId>0915fc2c-0054-4407-9f25-873fc5b8af9f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@password = concat('.//*[@id=' , &quot;'&quot; , 'Login1_Password' , &quot;'&quot; , ']')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>.//*[@id='Login1_Password']</value>
   </webElementProperties>
</WebElementEntity>
