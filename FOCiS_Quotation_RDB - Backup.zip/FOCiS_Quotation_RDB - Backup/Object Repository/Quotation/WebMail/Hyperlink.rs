<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Hyperlink</name>
   <tag></tag>
   <elementGuidId>61f38109-3210-4a07-82e8-8ddd820d42da</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(.,'Please click here for your review and acceptance')]</value>
   </webElementProperties>
</WebElementEntity>
