<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>First_Sell_Rate</name>
   <tag></tag>
   <elementGuidId>1d7e3565-6434-497a-9e9f-d59f1fdd080e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//input[@class='PWCTextBox input-block-level text-right'])[1]</value>
   </webElementProperties>
</WebElementEntity>
