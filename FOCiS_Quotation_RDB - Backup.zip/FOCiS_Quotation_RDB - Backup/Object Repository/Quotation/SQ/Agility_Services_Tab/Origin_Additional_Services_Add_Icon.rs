<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Origin_Additional_Services_Add_Icon</name>
   <tag></tag>
   <elementGuidId>115ba1de-4110-4214-863f-ed9c8f9f58f9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'Additional Services and Applicable Charges')]/../a[@title='Add Charge'])[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'Additional Services and Applicable Charges')]/../a[@title='Add Charge'])[1]</value>
   </webElementProperties>
</WebElementEntity>
