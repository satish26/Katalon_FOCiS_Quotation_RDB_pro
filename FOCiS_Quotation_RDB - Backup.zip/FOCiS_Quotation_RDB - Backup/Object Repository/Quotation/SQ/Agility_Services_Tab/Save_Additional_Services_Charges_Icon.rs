<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save_Additional_Services_Charges_Icon</name>
   <tag></tag>
   <elementGuidId>ccf42d83-2daf-4a7d-97f5-c173e63efb89</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@data-original-title='Associate Selected Rows']</value>
   </webElementProperties>
</WebElementEntity>
