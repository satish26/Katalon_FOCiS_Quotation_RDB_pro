<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Destination_Additional_Services_Add_Icon</name>
   <tag></tag>
   <elementGuidId>ca640921-dc37-4308-8ff7-44c6ff279ec9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//span[contains(text(),'Additional Services and Applicable Charges')]/../a[@title='Add Charge'])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[contains(text(),'Additional Services and Applicable Charges')]/../a[@title='Add Charge'])[2]</value>
   </webElementProperties>
</WebElementEntity>
