<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Quote Customer Ref.No</name>
   <tag></tag>
   <elementGuidId>01668633-f3d9-49cf-b5bf-3cfdbd5966ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteFrUc_QuoteFrUc_txtQuoteCustRefNumber']</value>
   </webElementProperties>
</WebElementEntity>
