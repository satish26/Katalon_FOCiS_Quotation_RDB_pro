<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Delete_Shipment_Icon</name>
   <tag></tag>
   <elementGuidId>295e7df2-590b-4e94-bc23-fe2c041748f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[contains(@class,'ui-icon icon-trash red')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[contains(@class,'ui-icon icon-trash red')]</value>
   </webElementProperties>
</WebElementEntity>
