<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Quotation_No_Get_Text</name>
   <tag></tag>
   <elementGuidId>282e2b50-b616-4d58-9625-c0a943050c90</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteFrUc_QuoteFrUc_lblQuotenumber' or @id='PWCMasterPage_PWCWebPartManager_gwpQuoteFrUc_QuoteFrUc_LblQNum']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteFrUc_QuoteFrUc_lblQuotenumber' or @id='PWCMasterPage_PWCWebPartManager_gwpQuoteFrUc_QuoteFrUc_LblQNum']</value>
   </webElementProperties>
</WebElementEntity>
