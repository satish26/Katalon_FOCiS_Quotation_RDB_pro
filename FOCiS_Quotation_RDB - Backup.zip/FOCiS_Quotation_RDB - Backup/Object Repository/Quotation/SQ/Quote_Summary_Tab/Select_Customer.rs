<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_Customer</name>
   <tag></tag>
   <elementGuidId>b9983278-a941-4a1a-b5e3-6a611c006fcd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'z AES TEST STAKEHOLDER')]</value>
   </webElementProperties>
</WebElementEntity>
