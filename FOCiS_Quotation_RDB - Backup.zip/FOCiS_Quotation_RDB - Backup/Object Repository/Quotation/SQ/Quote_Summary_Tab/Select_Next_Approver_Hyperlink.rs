<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Select_Next_Approver_Hyperlink</name>
   <tag></tag>
   <elementGuidId>a3d281de-4c96-4feb-82b4-ea42b51b1191</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[(text()='topuser2-branch' or text()='TOPUSER2_DXB') or text()='topuser2_dxb']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>Css</name>
      <type>Main</type>
      <value>//a[text()='Topuser2_branch' or text()='topuser2_branch']</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[(text()='topuser2-branch' or text()='TOPUSER2_DXB') or text()='topuser2_dxb']</value>
   </webElementProperties>
</WebElementEntity>
