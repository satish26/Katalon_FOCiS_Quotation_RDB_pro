<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>This XPATH is same in Quote Info tab, Agility Services tab and International Freight tab.</description>
   <name>Save_and_Continue</name>
   <tag></tag>
   <elementGuidId>6a6412f3-04bc-4be3-8f4b-122849e4bc3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@title='Save and Continue']</value>
   </webElementProperties>
</WebElementEntity>
