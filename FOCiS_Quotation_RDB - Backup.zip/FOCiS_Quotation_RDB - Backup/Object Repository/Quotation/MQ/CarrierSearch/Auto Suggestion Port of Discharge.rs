<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Auto Suggestion Port of Discharge</name>
   <tag></tag>
   <elementGuidId>8f554fd1-782d-427f-b1b9-6b672d83e57b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='PWCMasterPage_PWCWebPartManager_gwpMQCarrierRateSearchFr_MQCarrierRateSearchFr_txtDestinationPort_divPopup']/ul/li/a</value>
   </webElementProperties>
</WebElementEntity>
