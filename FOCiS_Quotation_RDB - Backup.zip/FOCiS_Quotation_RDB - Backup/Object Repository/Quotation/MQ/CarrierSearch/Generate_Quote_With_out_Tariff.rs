<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Generate_Quote_With_out_Tariff</name>
   <tag></tag>
   <elementGuidId>66254bcf-1eb5-4252-90cb-f95ee7347da5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMQCarrierRateSearchFr_MQCarrierRateSearchFr_btnGenerateQuote']</value>
   </webElementProperties>
</WebElementEntity>
