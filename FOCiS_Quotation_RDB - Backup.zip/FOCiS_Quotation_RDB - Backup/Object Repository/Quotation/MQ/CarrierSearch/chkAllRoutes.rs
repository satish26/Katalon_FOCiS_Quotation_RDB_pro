<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chkAllRoutes</name>
   <tag></tag>
   <elementGuidId>d86c7138-f9b1-41a5-8fd2-6833c4981c56</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='chkAllRoutes']</value>
   </webElementProperties>
</WebElementEntity>
