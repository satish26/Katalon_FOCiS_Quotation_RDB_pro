<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Auto Suggestion Port of Loading</name>
   <tag></tag>
   <elementGuidId>fe318ff1-7c3f-4385-bdfb-a307ed4dfc18</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@id='PWCMasterPage_PWCWebPartManager_gwpMQCarrierRateSearchFr_MQCarrierRateSearchFr_txtOriginPort_divPopup']/ul/li/a</value>
   </webElementProperties>
</WebElementEntity>
