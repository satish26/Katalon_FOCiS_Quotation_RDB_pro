<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>RateCart</name>
   <tag></tag>
   <elementGuidId>dbdbd5c3-9b63-40e7-ab34-7c4e6894a3e9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='cart']</value>
   </webElementProperties>
</WebElementEntity>
