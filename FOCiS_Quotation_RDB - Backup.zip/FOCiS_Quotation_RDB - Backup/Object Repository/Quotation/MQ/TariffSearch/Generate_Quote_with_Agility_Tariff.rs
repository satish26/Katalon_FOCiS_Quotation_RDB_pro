<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Generate_Quote_with_Agility_Tariff</name>
   <tag></tag>
   <elementGuidId>24040625-bdc5-4012-87a1-cd00fe236f7c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMQAgilityRateSearchLsUc_MQAgilityRateSearchLsUc_btnGenerateQuote']</value>
   </webElementProperties>
</WebElementEntity>
