<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Search_Agility_Tariff</name>
   <tag></tag>
   <elementGuidId>edb150f4-c7a6-449b-8715-5d24f2279306</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMQAgilityRateSearchLsUc_MQAgilityRateSearchLsUc_btnSave']</value>
   </webElementProperties>
</WebElementEntity>
