<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ChargeSummaryTab</name>
   <tag></tag>
   <elementGuidId>b7ef126d-7a03-481e-9829-ab1fd993ecbf</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'Charge Summary')]</value>
   </webElementProperties>
</WebElementEntity>
