<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>QuoteSummaryTab</name>
   <tag></tag>
   <elementGuidId>13c92f0c-3cf8-4895-85ab-45ec0696be31</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quote Summary')]</value>
   </webElementProperties>
</WebElementEntity>
