<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>QutoInfoTab</name>
   <tag></tag>
   <elementGuidId>2c97d57d-0653-4e11-bc99-5bcd1d523936</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'Quote Info')]</value>
   </webElementProperties>
</WebElementEntity>
