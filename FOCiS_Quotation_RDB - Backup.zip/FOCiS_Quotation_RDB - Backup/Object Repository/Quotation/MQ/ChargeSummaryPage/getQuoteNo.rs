<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>getQuoteNo</name>
   <tag></tag>
   <elementGuidId>b13db1af-e8c3-401a-a44c-451895f759f9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//Span[@class='label label-transparent'])[1]</value>
   </webElementProperties>
</WebElementEntity>
