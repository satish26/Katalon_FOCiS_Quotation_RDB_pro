<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SaveAndContinue</name>
   <tag></tag>
   <elementGuidId>2d71193d-9dac-4087-829d-8ae1048b18ca</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMQIntFreightLsUc_MQIntFreightLsUc_btnSaveCon']</value>
   </webElementProperties>
</WebElementEntity>
