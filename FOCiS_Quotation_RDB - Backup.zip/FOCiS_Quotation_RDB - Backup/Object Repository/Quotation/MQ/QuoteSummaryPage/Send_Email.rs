<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Send_Email</name>
   <tag></tag>
   <elementGuidId>028eefce-0298-42cb-962c-80478f566002</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuotePreviewFrUc_MultiQuotePreviewFrUc_drpSendEMailtoCustomer']</value>
   </webElementProperties>
</WebElementEntity>
