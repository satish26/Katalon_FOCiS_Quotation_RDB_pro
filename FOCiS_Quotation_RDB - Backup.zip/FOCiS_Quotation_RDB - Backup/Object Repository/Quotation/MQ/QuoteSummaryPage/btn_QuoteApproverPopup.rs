<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_QuoteApproverPopup</name>
   <tag></tag>
   <elementGuidId>6e655cf1-3b5b-414d-b3f4-af88b416178d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//button[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuotePreviewFrUc_MultiQuotePreviewFrUc_txtNextApprover_btnPopup']</value>
   </webElementProperties>
</WebElementEntity>
