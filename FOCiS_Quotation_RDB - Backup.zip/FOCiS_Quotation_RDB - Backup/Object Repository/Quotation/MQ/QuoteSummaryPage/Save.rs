<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Save</name>
   <tag></tag>
   <elementGuidId>fa678347-86bc-4b77-a0be-957eb2f10abc</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuotePreviewFrUc_MultiQuotePreviewFrUc_btnSave']</value>
   </webElementProperties>
</WebElementEntity>
