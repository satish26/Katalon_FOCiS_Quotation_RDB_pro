<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Email Address</name>
   <tag></tag>
   <elementGuidId>5b9b1665-b2af-4380-95a4-622013b3ffa5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuotePreviewFrUc_MultiQuotePreviewFrUc_txtEMailIDsTo']</value>
   </webElementProperties>
</WebElementEntity>
