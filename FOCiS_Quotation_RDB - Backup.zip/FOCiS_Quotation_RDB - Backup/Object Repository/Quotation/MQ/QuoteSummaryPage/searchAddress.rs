<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>searchAddress</name>
   <tag></tag>
   <elementGuidId>cafb8a02-9819-4d63-bf15-46bf7eb5c91c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='gs_Address']</value>
   </webElementProperties>
</WebElementEntity>
