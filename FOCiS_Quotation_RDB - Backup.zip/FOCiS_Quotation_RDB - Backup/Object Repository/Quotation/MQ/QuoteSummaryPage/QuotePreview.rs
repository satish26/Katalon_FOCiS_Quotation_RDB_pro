<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>QuotePreview</name>
   <tag></tag>
   <elementGuidId>75f01153-f7ca-49c2-bd9b-92f0617e8f34</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuotePreviewFrUc_MultiQuotePreviewFrUc_btnPreviePdf']</value>
   </webElementProperties>
</WebElementEntity>
