<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectAddress</name>
   <tag></tag>
   <elementGuidId>bfc02970-13ba-488d-8824-94514d51b837</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[contains(text(),'z AES TEST STAKEHOLDER')]</value>
   </webElementProperties>
</WebElementEntity>
