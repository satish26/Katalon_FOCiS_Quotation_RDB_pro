<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>searchUser</name>
   <tag></tag>
   <elementGuidId>c18ebc7d-951a-4d53-b504-a9fc559a7a74</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='gs_DataId']</value>
   </webElementProperties>
</WebElementEntity>
