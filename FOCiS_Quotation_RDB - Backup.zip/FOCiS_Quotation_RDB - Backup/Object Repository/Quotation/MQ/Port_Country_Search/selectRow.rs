<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectRow</name>
   <tag></tag>
   <elementGuidId>390e64b8-b73a-4fc6-b092-adf636cc3f38</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(@id,'jqg_pnlPopupGrid_')]</value>
   </webElementProperties>
</WebElementEntity>
