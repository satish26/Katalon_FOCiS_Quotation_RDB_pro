<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Associate</name>
   <tag></tag>
   <elementGuidId>29f51ef3-b9bc-453c-a4a9-ba9ef8c9e676</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class='ui-icon icon-save purple']</value>
   </webElementProperties>
</WebElementEntity>
