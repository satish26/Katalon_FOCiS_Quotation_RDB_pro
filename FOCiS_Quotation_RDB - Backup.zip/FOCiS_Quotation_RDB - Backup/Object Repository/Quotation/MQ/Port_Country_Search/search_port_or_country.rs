<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>search_port_or_country</name>
   <tag></tag>
   <elementGuidId>0866e9ae-75cd-42a1-bd30-65317867fcdb</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='gs_DataCode']</value>
   </webElementProperties>
</WebElementEntity>
