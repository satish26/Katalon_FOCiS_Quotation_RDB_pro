<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Mask</name>
   <tag></tag>
   <elementGuidId>ec706e78-bdb0-4ec1-8c45-dc4e5ef81512</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='loadmask']</value>
   </webElementProperties>
</WebElementEntity>
