<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Save</name>
   <tag></tag>
   <elementGuidId>5f0eb050-447f-48ee-8bba-66e44a3a5790</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuoteFrUc_MultiQuoteFrUc_btnSave']</value>
   </webElementProperties>
</WebElementEntity>
