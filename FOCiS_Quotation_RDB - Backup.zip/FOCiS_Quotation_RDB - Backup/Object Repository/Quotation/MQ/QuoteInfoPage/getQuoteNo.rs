<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>getQuoteNo</name>
   <tag></tag>
   <elementGuidId>d15a7403-2d52-446e-9ce8-d6bd8442b6a3</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuoteFrUc_MultiQuoteFrUc_LblQNum']</value>
   </webElementProperties>
</WebElementEntity>
