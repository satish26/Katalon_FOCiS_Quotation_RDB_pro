<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_Save_and_Continue</name>
   <tag></tag>
   <elementGuidId>07d971eb-8666-4eab-b4ce-354d946a2ec5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuoteFrUc_MultiQuoteFrUc_btnContinue']</value>
   </webElementProperties>
</WebElementEntity>
