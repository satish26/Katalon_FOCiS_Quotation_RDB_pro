<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description>XX</description>
   <name>Add Cargo Desription</name>
   <tag></tag>
   <elementGuidId>0128fb65-4126-487a-a96c-3d043535ce21</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//textarea[@id='PWCMasterPage_PWCWebPartManager_gwpMultiQuoteFrUc_MultiQuoteFrUc_MultiQuoteShipmentFrUc_txtShpmntDescription']</value>
   </webElementProperties>
</WebElementEntity>
