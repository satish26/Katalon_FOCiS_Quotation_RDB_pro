<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>International_Freight_Tab</name>
   <tag></tag>
   <elementGuidId>ed5aefd6-6d6b-453b-b359-4f19b1c8fdf3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a[text()='International Freight' or @id='PWCMasterPage_PWCWebPartManager_gwpQuoteWizardFrUc_QuoteWizardFrUc_ctrlInternationFreightChargesV2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[text()='International Freight' or @id='PWCMasterPage_PWCWebPartManager_gwpQuoteWizardFrUc_QuoteWizardFrUc_ctrlInternationFreightChargesV2']</value>
   </webElementProperties>
</WebElementEntity>
