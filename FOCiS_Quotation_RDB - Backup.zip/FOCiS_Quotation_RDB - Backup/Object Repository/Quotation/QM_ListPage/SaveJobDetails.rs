<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SaveJobDetails</name>
   <tag></tag>
   <elementGuidId>900ff4f0-0d8a-40a1-bcb7-513c771d50d9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id='PWCMasterPage_PWCWebPartManager_gwpMQJobNumberFrUc_MQJobNumberFrUc_btnCreate']</value>
   </webElementProperties>
</WebElementEntity>
