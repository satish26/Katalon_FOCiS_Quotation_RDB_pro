<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>JobNo</name>
   <tag></tag>
   <elementGuidId>a439b7cf-e467-4bd0-8dee-f45b55a1f995</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>contains</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[contains(@id,'txtJobNUm_')]</value>
   </webElementProperties>
</WebElementEntity>
