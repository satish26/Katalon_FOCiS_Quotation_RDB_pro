<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>HistoryIcon</name>
   <tag></tag>
   <elementGuidId>e7cbbfe9-f399-4162-8379-5d01b18a9a09</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class='ui-icon icon-time black']</value>
   </webElementProperties>
</WebElementEntity>
