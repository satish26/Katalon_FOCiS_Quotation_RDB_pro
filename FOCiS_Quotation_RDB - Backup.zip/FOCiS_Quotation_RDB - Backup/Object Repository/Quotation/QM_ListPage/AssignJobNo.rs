<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssignJobNo</name>
   <tag></tag>
   <elementGuidId>5fc7118c-117f-473d-b156-fc1a76af1eee</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class='ui-icon icon-upload blue']</value>
   </webElementProperties>
</WebElementEntity>
