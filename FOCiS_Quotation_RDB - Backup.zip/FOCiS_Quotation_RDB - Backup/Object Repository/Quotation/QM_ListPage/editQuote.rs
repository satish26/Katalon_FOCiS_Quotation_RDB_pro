<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>editQuote</name>
   <tag></tag>
   <elementGuidId>39fbb054-1550-4865-a57c-6f115acdf65b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//span[@class='ui-icon ui-icon-pencil blue']</value>
   </webElementProperties>
</WebElementEntity>
