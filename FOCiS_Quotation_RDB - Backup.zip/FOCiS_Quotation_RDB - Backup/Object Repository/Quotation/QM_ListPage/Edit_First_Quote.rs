<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Edit_First_Quote</name>
   <tag></tag>
   <elementGuidId>9ee8ae95-3ed4-43d6-aaf7-0573c246533a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//span[@class='ui-icon ui-icon-pencil blue'])[1]</value>
   </webElementProperties>
</WebElementEntity>
