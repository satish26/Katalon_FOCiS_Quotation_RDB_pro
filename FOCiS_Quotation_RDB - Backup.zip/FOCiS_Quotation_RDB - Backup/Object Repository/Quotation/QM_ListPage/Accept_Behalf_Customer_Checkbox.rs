<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Accept_Behalf_Customer_Checkbox</name>
   <tag></tag>
   <elementGuidId>9a241453-004f-4467-8ee4-858768e043f7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@data-original-title='Accept on behalf of Customer']</value>
   </webElementProperties>
</WebElementEntity>
