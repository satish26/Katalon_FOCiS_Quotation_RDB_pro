<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>AssignJobNoFrame</name>
   <tag></tag>
   <elementGuidId>0b3d6715-966f-47f0-a84b-54b9b222b3a1</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//iframe[@class='fancybox-iframe']</value>
   </webElementProperties>
</WebElementEntity>
