<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>searchQuoteNo</name>
   <tag></tag>
   <elementGuidId>3e6bd8c6-f1c6-4598-8650-d6212c46da94</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//input[@id='gs_QUOTATIONNUMBER']</value>
   </webElementProperties>
</WebElementEntity>
