<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CloseJobDetailsPopUp</name>
   <tag></tag>
   <elementGuidId>b9fe6d2e-505f-4ecf-9f85-3091399f63c6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@title='Close']</value>
   </webElementProperties>
</WebElementEntity>
