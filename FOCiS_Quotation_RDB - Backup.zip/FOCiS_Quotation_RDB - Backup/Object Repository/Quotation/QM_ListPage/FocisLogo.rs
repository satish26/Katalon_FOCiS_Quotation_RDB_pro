<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>FocisLogo</name>
   <tag></tag>
   <elementGuidId>07aef470-0b52-43d1-9690-8a17c2580a45</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a[@class='FOCISlogo']</value>
   </webElementProperties>
</WebElementEntity>
