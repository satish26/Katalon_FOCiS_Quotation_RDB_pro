<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Quotation_Template _Search_Result_text</name>
   <tag></tag>
   <elementGuidId>81250590-1845-4a29-8d90-99e5619eb73d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@id='grdQuoteTemplateLsPager_right']/div</value>
   </webElementProperties>
</WebElementEntity>
