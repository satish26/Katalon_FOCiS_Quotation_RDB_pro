<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Air_Mode</name>
   <tag></tag>
   <elementGuidId>147f0002-51c8-4f67-a4d4-30edeb654c7e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//label[@class=&quot;air air-check&quot;]/div/ins</value>
   </webElementProperties>
</WebElementEntity>
