<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CargoDetailsHeader</name>
   <tag></tag>
   <elementGuidId>1467c227-34eb-45a3-8ad9-0d1a2809e21d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//h4[contains(text(),'Cargo Details')]</value>
   </webElementProperties>
</WebElementEntity>
