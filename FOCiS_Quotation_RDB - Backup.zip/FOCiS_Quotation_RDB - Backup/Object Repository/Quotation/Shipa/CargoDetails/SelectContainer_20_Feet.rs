<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectContainer_20_Feet</name>
   <tag></tag>
   <elementGuidId>62845d23-cf05-4154-9a41-d008c0fdcac1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[contains(text(),&quot;20' General Purpose&quot;)]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[contains(text(),&quot;20' General Purpose&quot;)]</value>
   </webElementProperties>
</WebElementEntity>
