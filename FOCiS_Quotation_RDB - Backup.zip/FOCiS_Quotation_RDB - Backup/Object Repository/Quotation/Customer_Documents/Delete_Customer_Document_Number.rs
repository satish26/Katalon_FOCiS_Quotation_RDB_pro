<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Delete_Customer_Document_Number</name>
   <tag></tag>
   <elementGuidId>66625265-7785-4af8-a01e-7bf3bd45ea01</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@data-original-title='Delete selected row']/div</value>
   </webElementProperties>
</WebElementEntity>
