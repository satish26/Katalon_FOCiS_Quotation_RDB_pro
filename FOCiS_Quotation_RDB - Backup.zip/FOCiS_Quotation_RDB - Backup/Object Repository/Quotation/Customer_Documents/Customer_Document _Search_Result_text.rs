<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Customer_Document _Search_Result_text</name>
   <tag></tag>
   <elementGuidId>87cfb570-bd4f-4671-a73a-c96d3d2d82e3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//td[@id='grdCustomerContractLsPager_right']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[@id='grdCustomerContractLsPager_right']/div</value>
   </webElementProperties>
</WebElementEntity>
