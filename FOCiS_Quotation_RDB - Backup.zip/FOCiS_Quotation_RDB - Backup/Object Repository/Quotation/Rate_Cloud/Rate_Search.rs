<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Rate_Search</name>
   <tag></tag>
   <elementGuidId>539ca54e-5d99-4229-b4f8-c96650f89ab2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a/span[text()='Rate Search']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a/span[text()='Rate Search']</value>
   </webElementProperties>
</WebElementEntity>
