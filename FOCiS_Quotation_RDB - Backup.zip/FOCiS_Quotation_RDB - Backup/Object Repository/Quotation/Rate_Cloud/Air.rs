<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Air</name>
   <tag></tag>
   <elementGuidId>989b2e44-1dd5-45fb-8b6f-b7854e4d7e58</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Air']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Air']</value>
   </webElementProperties>
</WebElementEntity>
