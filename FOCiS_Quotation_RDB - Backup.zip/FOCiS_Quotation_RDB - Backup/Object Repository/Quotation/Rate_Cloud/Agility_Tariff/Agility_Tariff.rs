<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Agility_Tariff</name>
   <tag></tag>
   <elementGuidId>ef9147c8-5aa0-44d3-b2e7-0f1bd90f6990</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Agility Tariff']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Agility Tariff']</value>
   </webElementProperties>
</WebElementEntity>
