<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Ocean</name>
   <tag></tag>
   <elementGuidId>24045fd1-93ff-452f-997a-551ded11cfeb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Ocean']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//a/span[text()='Rate Search']/../following-sibling::*//span[text()='Ocean']</value>
   </webElementProperties>
</WebElementEntity>
