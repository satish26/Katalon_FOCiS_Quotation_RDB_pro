<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Delete_Contact_Details</name>
   <tag></tag>
   <elementGuidId>3cbf38b3-47ae-49b6-b383-855e72879709</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//td[text()='${xpath}']/../td[contains(@aria-describedby,'Contact_Action')]/div[@data-original-title='Delete selected row']</value>
   </webElementProperties>
</WebElementEntity>
