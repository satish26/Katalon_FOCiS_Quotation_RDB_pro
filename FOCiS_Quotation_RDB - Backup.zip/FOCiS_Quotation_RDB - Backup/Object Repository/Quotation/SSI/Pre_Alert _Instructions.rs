<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Pre_Alert _Instructions</name>
   <tag></tag>
   <elementGuidId>b5c3bfb5-afa1-488a-a7d5-a87cda2508d8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//textarea[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteSSIFrUc_QuoteSSIFrUc_txtPrealert']</value>
   </webElementProperties>
</WebElementEntity>
