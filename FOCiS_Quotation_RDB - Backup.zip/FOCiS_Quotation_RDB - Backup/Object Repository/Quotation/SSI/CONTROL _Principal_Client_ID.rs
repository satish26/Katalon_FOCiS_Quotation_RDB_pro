<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>CONTROL _Principal_Client_ID</name>
   <tag></tag>
   <elementGuidId>74764b6b-b612-453b-8de9-67a9f25b1084</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//textarea[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteSSIFrUc_QuoteSSIFrUc_txtContrlPrincplClient']</value>
   </webElementProperties>
</WebElementEntity>
