<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Billing Address</name>
   <tag></tag>
   <elementGuidId>5fd933f1-c320-4835-bf4d-0030c8b00721</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//textarea[@id='PWCMasterPage_PWCWebPartManager_gwpQuoteSSIFrUc_QuoteSSIFrUc_txtbillingAddress']</value>
   </webElementProperties>
</WebElementEntity>
